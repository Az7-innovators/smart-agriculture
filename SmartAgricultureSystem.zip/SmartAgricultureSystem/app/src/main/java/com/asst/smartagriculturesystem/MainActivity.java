package com.asst.smartagriculturesystem;


import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.drafts.Draft_17;
import org.java_websocket.handshake.ServerHandshake;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URI;
import java.net.URISyntaxException;

import static xdroid.toaster.Toaster.toast;

public class MainActivity extends AppCompatActivity {

    private TextView t1;
    private TextView v1;
    private TextView t2;
    private TextView v2;
    private TextView t3;
    private TextView v3;
    private TextView t4;
    private TextView v4;
    private TextView t5;
    private TextView v5;
    private TextView t6;
    private TextView v6;
    private TextView t7;
    private TextView v7;
    private TextView t8;
    private TextView v8;
    WebSocketClient mWebSocketClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViews();
//        connectWebSocket();


        v1.setText(String.valueOf("0")+" \u00B0");
        v2.setText(String.valueOf("0")+" \u0025");
        v3.setText(String.valueOf("0")+" ");
        v4.setText(String.valueOf("0")+" m");
        v5.setText(String.valueOf("0")+" hP");
        v6.setText(String.valueOf("0")+" m/s");
        v7.setText(String.valueOf("0")+" ");
        v8.setText(String.valueOf("0")+" \u0025");

    }
    private void findViews() {
        t1 = (TextView)findViewById( R.id.t1 );
        v1 = (TextView)findViewById( R.id.v1 );
        t2 = (TextView)findViewById( R.id.t2 );
        v2 = (TextView)findViewById( R.id.v2 );
        t3 = (TextView)findViewById( R.id.t3 );
        v3 = (TextView)findViewById( R.id.v3 );
        t4 = (TextView)findViewById( R.id.t4 );
        v4 = (TextView)findViewById( R.id.v4 );
        t5 = (TextView)findViewById( R.id.t5 );
        v5 = (TextView)findViewById( R.id.v5 );
        t6 = (TextView)findViewById( R.id.t6 );
        v6 = (TextView)findViewById( R.id.v6 );
        t7 = (TextView)findViewById( R.id.t7 );
        v7 = (TextView)findViewById( R.id.v7 );
        t8 = (TextView)findViewById( R.id.t8 );
        v8 = (TextView)findViewById( R.id.v8 );
    }
    private void connectWebSocket()
    {
        URI uri;

        try {
            uri = new URI("ws://192.168.4.1:81");
            toast("Connecting.....");
        } catch (URISyntaxException e)
        {
            e.printStackTrace();
            return;
        }

        mWebSocketClient = new WebSocketClient(uri,new Draft_17())
        {

            @Override
            public void onOpen(ServerHandshake handshakedata)
            {
                toast("Connected Successfully");

                    runOnUiThread(new Runnable()
                    {
                        public void run()
                        {

                        }
                    });
            }

            @Override
            public void onMessage(String message)
            {

                Log.e("Websocket", "onMessage="+message);

                try
                {
                    JSONObject jsonObject = new JSONObject(message);
                    v1.setText(String.valueOf(jsonObject.getDouble("V1"))+" \u00B0");
                    v2.setText(String.valueOf(jsonObject.getDouble("V2"))+" \u0025");
                    v3.setText(String.valueOf(jsonObject.getDouble("V3"))+" ");
                    v4.setText(String.valueOf(jsonObject.getDouble("V4"))+" m");
                    v5.setText(String.valueOf(jsonObject.getDouble("V5"))+" hP");
                    v6.setText(String.valueOf(jsonObject.getDouble("V6"))+" m/s");
                    v7.setText(String.valueOf(jsonObject.getInt("V7"))+" ");
                    v8.setText(String.valueOf(jsonObject.getInt("V8"))+" \u0025");


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onClose(int code, String reason, boolean remote) {
                Log.e("Websocket", "closed="+reason);
                toast("Disconnected");
                v1.setText(String.valueOf("0")+" \u00B0");
                v2.setText(String.valueOf("0")+" \u0025");
                v3.setText(String.valueOf("0")+" ");
                v4.setText(String.valueOf("0")+" m");
                v5.setText(String.valueOf("0")+" hP");
                v6.setText(String.valueOf("0")+" m/s");
                v7.setText(String.valueOf("0")+" ");
                v8.setText(String.valueOf("0")+" \u0025");
            }

            @Override
            public void onError(Exception ex) {
                Log.e("Websocket", "exception =" + ex);
                v1.setText(String.valueOf("0")+" \u00B0");
                v2.setText(String.valueOf("0")+" \u0025");
                v3.setText(String.valueOf("0")+" ");
                v4.setText(String.valueOf("0")+" m");
                v5.setText(String.valueOf("0")+" hP");
                v6.setText(String.valueOf("0")+" m/s");
                v7.setText(String.valueOf("0")+" ");
                v8.setText(String.valueOf("0")+" \u0025");
            }



        };
        mWebSocketClient.connect();
    }

    public void connect(View view)
    {
        connectWebSocket();
    }
}






